var messages = ["&e▸ Нажмите, чтобы использовать", "&e Нажмите, чтобы использовать"];
var numdata = "%player_name%." + IDv + "." + messages;
var IDv = 0;

function getMessage(ID) {
    if ( args.length == 3) {
        IDv = args[0];
        messages = [args[1], args[2]];
    }

    var msgnumber = Data.exists(numdata) ? Data.get(numdata) : 0;
    msgnumber++;

    if (msgnumber >= 2) {
        msgnumber = 0;
    }

    Data.set(numdata, msgnumber);

    return messages[msgnumber];
}
getMessage(IDv);