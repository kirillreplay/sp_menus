var messages = ["&7В разработке.", "&7В разработке..", "&7В разработке..."];
var numdata = "%player_name%." + IDv + "." + messages;
var IDv = 1;

function getMessage(ID) {
    if ( args.length == 4) {
        IDv = args[0];
        messages = [args[1], args[2], args[3]];
    }

    var msgnumber = Data.exists(numdata) ? Data.get(numdata) : 0;
    msgnumber++;

    if (msgnumber >= 3) {
        msgnumber = 0;
    }

    Data.set(numdata, msgnumber);

    return messages[msgnumber];
}
getMessage(IDv);